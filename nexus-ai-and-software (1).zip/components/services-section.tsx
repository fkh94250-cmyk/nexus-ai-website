import { Code2, Smartphone, BrainCircuit, Palette, type LucideIcon } from 'lucide-react'
import { Reveal } from '@/components/reveal'

type Service = {
  icon: LucideIcon
  title: string
  en: string
  description: string
  features: string[]
}

const services: Service[] = [
  {
    icon: Code2,
    title: 'Web Geliştirme',
    en: 'Web Development',
    description:
      'Yüksek performanslı, SEO uyumlu ve ölçeklenebilir web uygulamaları. Next.js ve modern altyapılarla kurumsal siteler ve platformlar.',
    features: ['Next.js & React', 'Kurumsal Web Siteleri', 'E-ticaret Platformları'],
  },
  {
    icon: Smartphone,
    title: 'Mobil Uygulama Geliştirme',
    en: 'Mobile App Development',
    description:
      'iOS ve Android için akıcı, native hissiyatlı mobil uygulamalar. Kullanıcı odaklı deneyim ve güçlü performans bir arada.',
    features: ['iOS & Android', 'Cross-Platform', 'App Store Yayını'],
  },
  {
    icon: BrainCircuit,
    title: 'Yapay Zeka Entegrasyonları',
    en: 'AI Integrations',
    description:
      'İş süreçlerinizi otomatikleştiren yapay zeka çözümleri. Chatbotlar, öneri sistemleri ve akıllı otomasyonlar.',
    features: ['LLM Entegrasyonu', 'Akıllı Chatbotlar', 'Süreç Otomasyonu'],
  },
  {
    icon: Palette,
    title: 'Kurumsal Kimlik & UI/UX Tasarımı',
    en: 'Graphic & Branding Design',
    description:
      'Markanızı yansıtan kurumsal kimlik ve kullanıcıyı merkeze alan arayüz tasarımları. Estetik ve işlevsellik dengesi.',
    features: ['Marka Kimliği', 'UI/UX Tasarımı', 'Tasarım Sistemleri'],
  },
]

export function ServicesSection() {
  return (
    <section id="hizmetler" className="scroll-mt-24 px-4 py-20 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium text-primary">Hizmetlerimiz</p>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Uçtan uca dijital çözümler
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground">
            Fikirden yayına kadar tüm dijital ihtiyaçlarınızı tek çatı altında karşılıyoruz.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          {services.map((service, i) => (
            <Reveal key={service.title} delay={i * 90}>
              <article className="group glass relative h-full overflow-hidden rounded-3xl p-7 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40">
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute -right-16 -top-16 size-40 rounded-full bg-primary/20 opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100"
                />
                <div className="relative flex items-start gap-4">
                  <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-primary/20 to-accent/20 text-primary transition-colors group-hover:text-foreground">
                    <service.icon className="size-6" />
                  </span>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">{service.title}</h3>
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground/70">
                      {service.en}
                    </p>
                  </div>
                </div>

                <p className="relative mt-5 text-sm leading-relaxed text-muted-foreground">
                  {service.description}
                </p>

                <ul className="relative mt-5 flex flex-wrap gap-2">
                  {service.features.map((f) => (
                    <li
                      key={f}
                      className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-muted-foreground"
                    >
                      {f}
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
