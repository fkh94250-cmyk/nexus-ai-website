'use client'

import { useState, type FormEvent } from 'react'
import { Check, Loader2, Mail, MapPin, Phone, Send } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const services = [
  'Web Geliştirme',
  'Mobil Uygulama Geliştirme',
  'Yapay Zeka Entegrasyonları',
  'Kurumsal Kimlik & UI/UX Tasarımı',
  'Diğer',
]

const contactInfo = [
  { icon: Mail, label: 'E-posta', value: 'merhaba@nexusai.com.tr' },
  { icon: Phone, label: 'Telefon', value: '+90 212 000 00 00' },
  { icon: MapPin, label: 'Adres', value: 'Maslak, İstanbul' },
]

const inputBase =
  'w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-all focus:border-primary/60 focus:ring-2 focus:ring-primary/20'

const WEB3FORMS_ACCESS_KEY = '3a43694b-9016-4a33-889f-29cea3902fce'

export function ContactSection() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setStatus('loading')

    const form = e.currentTarget
    const data = new FormData(form)
    data.append('access_key', WEB3FORMS_ACCESS_KEY)
    data.append('subject', 'Yeni Teklif Talebi — NEXUS AI & Software')
    data.append('from_name', 'NEXUS AI & Software')

    try {
      const res = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: { Accept: 'application/json' },
        body: data,
      })
      const result = await res.json()
      if (result.success) {
        form.reset()
        setStatus('success')
      } else {
        setStatus('error')
      }
    } catch {
      setStatus('error')
    }
  }

  return (
    <section id="iletisim" className="scroll-mt-24 px-4 py-20 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          <Reveal>
            <p className="text-sm font-medium text-primary">İletişim</p>
            <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              Projenizi birlikte hayata geçirelim
            </h2>
            <p className="mt-4 text-pretty text-muted-foreground">
              Formu doldurun, ekibimiz en kısa sürede size özel teklifiyle geri dönsün.
              Fikirlerinizi dinlemek için buradayız.
            </p>

            <ul className="mt-9 space-y-4">
              {contactInfo.map((item) => (
                <li key={item.label} className="flex items-center gap-4">
                  <span className="flex size-11 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-primary/15 to-accent/15 text-primary">
                    <item.icon className="size-5" />
                  </span>
                  <div>
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    <p className="text-sm font-medium text-foreground">{item.value}</p>
                  </div>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={120}>
            <div className="glass rounded-3xl p-6 sm:p-8">
              {status === 'success' ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                  <span className="flex size-16 items-center justify-center rounded-full bg-primary/15 text-primary shadow-[0_0_30px_-4px_rgba(34,211,238,0.6)]">
                    <Check className="size-8" />
                  </span>
                  <h3 className="mt-6 text-xl font-semibold text-foreground">
                    Teklif talebiniz alındı!
                  </h3>
                  <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                    Teşekkür ederiz. Ekibimiz en kısa sürede sizinle iletişime geçecek.
                  </p>
                  <button
                    type="button"
                    onClick={() => setStatus('idle')}
                    className="mt-6 rounded-xl border border-white/10 px-5 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-white/5"
                  >
                    Yeni Talep Oluştur
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="name" className="mb-1.5 block text-sm font-medium">
                        Ad Soyad
                      </label>
                      <input id="name" name="name" required placeholder="Adınız Soyadınız" className={inputBase} />
                    </div>
                    <div>
                      <label htmlFor="email" className="mb-1.5 block text-sm font-medium">
                        E-posta
                      </label>
                      <input id="email" name="email" type="email" required placeholder="ornek@sirket.com" className={inputBase} />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="phone" className="mb-1.5 block text-sm font-medium">
                        Telefon
                      </label>
                      <input id="phone" name="phone" type="tel" placeholder="+90 5xx xxx xx xx" className={inputBase} />
                    </div>
                    <div>
                      <label htmlFor="service" className="mb-1.5 block text-sm font-medium">
                        Hizmet Seçimi
                      </label>
                      <select id="service" name="service" required defaultValue="" className={inputBase}>
                        <option value="" disabled>
                          Bir hizmet seçin
                        </option>
                        {services.map((service) => (
                          <option key={service} value={service} className="bg-card">
                            {service}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="details" className="mb-1.5 block text-sm font-medium">
                      Proje Detayları
                    </label>
                    <textarea
                      id="details"
                      name="details"
                      required
                      rows={5}
                      placeholder="Projeniz hakkında kısaca bilgi verin..."
                      className={`${inputBase} resize-none`}
                    />
                  </div>

                  {status === 'error' && (
                    <p className="rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                      Bir hata oluştu. Lütfen tekrar deneyin veya e-posta ile iletişime geçin.
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={status === 'loading'}
                    className="group inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_0_30px_-4px_rgba(34,211,238,0.6)] transition-all hover:shadow-[0_0_40px_0px_rgba(34,211,238,0.75)] hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    {status === 'loading' ? (
                      <>
                        <Loader2 className="size-4 animate-spin" />
                        Gönderiliyor...
                      </>
                    ) : (
                      <>
                        Teklif Talebini Gönder
                        <Send className="size-4 transition-transform group-hover:translate-x-0.5" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
