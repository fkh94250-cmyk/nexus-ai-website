import { Search, PenTool, Code, Rocket, type LucideIcon } from 'lucide-react'
import { Reveal } from '@/components/reveal'

type Step = {
  icon: LucideIcon
  step: string
  title: string
  description: string
}

const steps: Step[] = [
  {
    icon: Search,
    step: '01',
    title: 'Keşif',
    description:
      'İhtiyaçlarınızı ve hedeflerinizi analiz ediyor, projenin yol haritasını birlikte belirliyoruz.',
  },
  {
    icon: PenTool,
    step: '02',
    title: 'Tasarım',
    description:
      'Marka kimliğinize uygun, kullanıcı odaklı arayüz ve deneyim tasarımlarını hazırlıyoruz.',
  },
  {
    icon: Code,
    step: '03',
    title: 'Geliştirme',
    description:
      'Modern teknolojilerle temiz, ölçeklenebilir ve güvenli kodu hayata geçiriyoruz.',
  },
  {
    icon: Rocket,
    step: '04',
    title: 'Yayınlama',
    description:
      'Test süreçlerinin ardından ürününüzü yayına alıyor ve sürekli destek sağlıyoruz.',
  },
]

export function ProcessSection() {
  return (
    <section id="surec" className="scroll-mt-24 px-4 py-20 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium text-primary">Çalışma Sürecimiz</p>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Fikirden ürüne, adım adım
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground">
            Şeffaf ve verimli bir süreçle projenizi her aşamada birlikte ilerletiyoruz.
          </p>
        </Reveal>

        <ol className="relative mt-16 grid gap-6 md:grid-cols-4">
          {/* connecting line */}
          <div
            aria-hidden="true"
            className="absolute left-0 right-0 top-6 hidden h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent md:block"
          />
          {steps.map((step, i) => (
            <Reveal as="li" key={step.step} delay={i * 120} className="relative">
              <div className="group glass h-full rounded-3xl p-6 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40">
                <div className="flex items-center justify-between">
                  <span className="relative flex size-12 items-center justify-center rounded-2xl border border-white/10 bg-background text-primary shadow-[0_0_20px_-6px_rgba(34,211,238,0.6)]">
                    <step.icon className="size-5" />
                  </span>
                  <span className="font-mono text-2xl font-semibold text-white/10 transition-colors group-hover:text-primary/30">
                    {step.step}
                  </span>
                </div>
                <h3 className="mt-5 text-lg font-semibold text-foreground">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {step.description}
                </p>
              </div>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  )
}
