import { ArrowRight, Sparkles } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const stats = [
  { value: '120+', label: 'Tamamlanan Proje' },
  { value: '45+', label: 'Mutlu Marka' },
  { value: '8 Yıl', label: 'Sektör Tecrübesi' },
]

export function HeroSection() {
  return (
    <section className="relative overflow-hidden px-4 pt-36 pb-20 sm:pt-44 sm:pb-28">
      <div className="mx-auto max-w-4xl text-center">
        <Reveal>
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground">
            <Sparkles className="size-3.5 text-primary" />
            Yapay Zeka Destekli Dijital Çözümler
          </span>
        </Reveal>

        <Reveal delay={80}>
          <h1 className="mt-6 text-balance text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl md:text-6xl">
            Geleceğin Yazılım ve Yapay Zeka Teknolojileriyle{' '}
            <span className="text-gradient">İşinizi Büyütün</span>
          </h1>
        </Reveal>

        <Reveal delay={160}>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            NEXUS AI &amp; Software olarak; web ve mobil uygulamalardan yapay zeka
            entegrasyonlarına kadar markanızı bir sonraki seviyeye taşıyacak modern,
            ölçeklenebilir ve estetik dijital ürünler geliştiriyoruz.
          </p>
        </Reveal>

        <Reveal delay={240}>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a
              href="#iletisim"
              className="group inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_0_30px_-4px_rgba(34,211,238,0.6)] transition-all hover:shadow-[0_0_40px_0px_rgba(34,211,238,0.75)] hover:brightness-110 sm:w-auto"
            >
              Hemen Teklif Alın
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </a>
            <a
              href="#referanslar"
              className="glass inline-flex w-full items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold text-foreground transition-all hover:border-primary/40 hover:bg-white/5 sm:w-auto"
            >
              Referanslarımız
            </a>
          </div>
        </Reveal>

        <Reveal delay={320}>
          <dl className="mx-auto mt-16 grid max-w-2xl grid-cols-3 gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="glass rounded-2xl px-3 py-5 text-center">
                <dt className="sr-only">{stat.label}</dt>
                <dd className="text-2xl font-semibold text-foreground sm:text-3xl">
                  {stat.value}
                </dd>
                <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{stat.label}</p>
              </div>
            ))}
          </dl>
        </Reveal>
      </div>
    </section>
  )
}
