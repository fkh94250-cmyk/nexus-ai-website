import { Sparkles } from 'lucide-react'

export function SiteFooter() {
  return (
    <footer className="border-t border-white/5 px-4 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent text-primary-foreground">
            <Sparkles className="size-4" />
          </span>
          <span className="text-sm font-semibold tracking-tight">
            NEXUS <span className="font-normal text-muted-foreground">AI &amp; Software</span>
          </span>
        </div>

        <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <a href="#hizmetler" className="transition-colors hover:text-foreground">Hizmetler</a>
          <a href="#referanslar" className="transition-colors hover:text-foreground">Referanslar</a>
          <a href="#surec" className="transition-colors hover:text-foreground">Süreç</a>
          <a href="#iletisim" className="transition-colors hover:text-foreground">İletişim</a>
        </nav>

        <p className="text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} NEXUS AI &amp; Software. Tüm hakları saklıdır.
        </p>
      </div>
    </footer>
  )
}
