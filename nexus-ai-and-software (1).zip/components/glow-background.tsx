export function GlowBackground() {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* subtle grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
          backgroundSize: '64px 64px',
          maskImage: 'radial-gradient(ellipse 80% 60% at 50% 0%, black 40%, transparent 100%)',
        }}
      />
      {/* cyan glow */}
      <div className="animate-blob-a absolute -top-40 -left-32 h-[36rem] w-[36rem] rounded-full bg-primary/25 blur-[130px]" />
      {/* violet glow */}
      <div className="animate-blob-b absolute top-1/3 -right-40 h-[40rem] w-[40rem] rounded-full bg-accent/25 blur-[140px]" />
      {/* deep bottom glow */}
      <div className="absolute bottom-0 left-1/2 h-[28rem] w-[28rem] -translate-x-1/2 rounded-full bg-primary/10 blur-[120px]" />
    </div>
  )
}
