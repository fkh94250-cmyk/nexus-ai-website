import Image from 'next/image'
import { ArrowUpRight } from 'lucide-react'
import { Reveal } from '@/components/reveal'

type Project = {
  title: string
  category: string
  image: string
  tags: string[]
}

const projects: Project[] = [
  {
    title: 'Kurumsal E-Ticaret Platformu',
    category: 'Web Geliştirme',
    image: '/projects/ecommerce.png',
    tags: ['Next.js', 'E-ticaret', 'Ödeme Entegrasyonu'],
  },
  {
    title: 'Fintech Mobil Uygulaması',
    category: 'Mobil Uygulama',
    image: '/projects/fintech-mobile.png',
    tags: ['iOS & Android', 'Fintech', 'UI/UX'],
  },
  {
    title: 'Yapay Zeka Destekli SaaS Paneli',
    category: 'AI Entegrasyonu',
    image: '/projects/ai-saas.png',
    tags: ['LLM', 'Dashboard', 'Otomasyon'],
  },
]

export function PortfolioSection() {
  return (
    <section id="referanslar" className="scroll-mt-24 px-4 py-20 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium text-primary">Referanslarımız</p>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Hayata geçirdiğimiz projeler
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground">
            Farklı sektörlerden markalar için geliştirdiğimiz bazı çalışmalar.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {projects.map((project, i) => (
            <Reveal key={project.title} delay={i * 100}>
              <article className="group glass relative h-full overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-1.5 hover:border-primary/40">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <Image
                    src={project.image || '/placeholder.svg'}
                    alt={`${project.title} arayüz önizlemesi`}
                    fill
                    sizes="(max-width: 768px) 100vw, 33vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent" />
                  <span className="absolute left-4 top-4 rounded-full border border-white/10 bg-background/60 px-3 py-1 text-xs font-medium text-primary backdrop-blur-md">
                    {project.category}
                  </span>
                  <span className="absolute right-4 top-4 flex size-9 translate-y-1 items-center justify-center rounded-full bg-primary text-primary-foreground opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                    <ArrowUpRight className="size-4" />
                  </span>
                </div>

                <div className="p-6">
                  <h3 className="text-lg font-semibold text-foreground">{project.title}</h3>
                  <ul className="mt-4 flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <li
                        key={tag}
                        className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-muted-foreground"
                      >
                        {tag}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
